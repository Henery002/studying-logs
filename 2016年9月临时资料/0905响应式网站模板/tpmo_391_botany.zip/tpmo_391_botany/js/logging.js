$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+854373+'&oi='+2135+'&ot=1&&url='+window.location, function(json){})    

});